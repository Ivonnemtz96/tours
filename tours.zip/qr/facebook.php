<script>
        window.location.replace("https://www.facebook.com/novotoursbcs");
</script>