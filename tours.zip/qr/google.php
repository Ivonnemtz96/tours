<script>
        window.location.replace("https://g.page/r/CV0GUE-UxPCtEBM/review");
</script>