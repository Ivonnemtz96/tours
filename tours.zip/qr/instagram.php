<script>
        window.location.replace("https://www.instagram.com/novotoursloscabos/");
</script>